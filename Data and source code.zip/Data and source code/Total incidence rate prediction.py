
import pandas as pd
from statsmodels.graphics.tsaplots import plot_acf
import pylab as plt
import statsmodels.api as sm
from statsmodels.tsa.arima.model import ARIMA
import numpy as np
import scipy.stats as stats
import xlsxwriter

plt.rc('axes',unicode_minus=False)
plt.rc('font',size=16)
plt.rc('font',family='SimHei')
df=pd.read_excel('Time series diagram dataset\Mongolia_I_B.xlsx',1)  
plt.figure()
plt.plot(df.data,df.value)
plt.figure()
plt.subplot(121)
plt.plot(df.value.diff())
plt.title('first difference')
ddf=df.value.diff().dropna()
ddf=np.array(ddf)
ax2=plt.subplot(122)
plot_acf(df.value.diff().dropna(),ax=ax2,title='autocorrelation')
plt.figure()
plt.subplot(121)
plt.plot(np.diff(ddf))
plt.title('second difference')
ax2=plt.subplot(122)
plot_acf(np.diff(ddf),ax=ax2,title='autocorrelation')
d=np.diff(ddf)
s=[]
for i in range(0,6):
    for j in range(0,6):
        md=ARIMA(d,order=(i,0,j)).fit()
        s.append([i,j,md.aic,md.bic])
a=s[0][3]
for i in range(25):
    if(s[i][3]<=a):
        a=s[i][3]
        b=s[i][0]
        c=s[i][1]
print(b,c)
md=ARIMA(df.value,order=(b,2,c))
mdf=md.fit()
print(mdf.summary())

resid=mdf.resid
r,q,p=sm.tsa.acf(resid.values.squeeze(),qstat=True)
mat_res=np.c_[range(1,15),r[1:],q,p] 
table=pd.DataFrame(mat_res,columns=['to lag','AC','Q','Prob(>Q)'])
LB_result_res=table.iloc[[5,11]]
LB_result_res.set_index('to lag',inplace=True)
LB_result_res

residuals=pd.DataFrame(mdf.resid)
sm.ProbPlot(mdf.resid, stats.t,fit=True).ppplot(line='45')
sm.ProbPlot(mdf.resid, stats.t,fit=True).qqplot(line='45')
fig,ax=plt.subplots(1,2)
residuals.plot(title='residual',ax=ax[0])
residuals.plot(kind='kde',title='density',ax=ax[1])
plt.legend('')
plt.ylabel('')


plot_acf(residuals,title='autocorrelation')

a=mdf.predict(end=len(df)+4)
mdf_int=mdf.conf_int(alpha=0.05)
plt.figure()
a[0]=df.value[0]
a[1]=df.value[1]
plt.plot(df.data,df.value)
plt.plot(range(1990,1990+len(a)),a)
plt.fill_between(pd.date_range(df.data[29], periods=10), mdf_int[:,0], mdf_int[:,1], color='pink', alpha=0.5) 
plt.show()
