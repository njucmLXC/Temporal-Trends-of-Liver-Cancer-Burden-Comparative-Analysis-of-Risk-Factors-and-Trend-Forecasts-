
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
NASH_m=pd.read_csv('China\China NASH Male.csv')
NASH_w=pd.read_csv('China\China NASH Fmale.csv')
C_m=pd.read_csv('China\China Hepatitis C Male.csv')
C_w=pd.read_csv('China\China Hepatitis C Fmale.csv')
B_m=pd.read_csv('China\China Hepatitis B Male.csv')
B_w=pd.read_csv('China\China Hepatitis B Fmale.csv')
Other_m=pd.read_csv('China\China Other Male.csv')
Other_w=pd.read_csv('China\China Other Fmale.csv')
A_m=pd.read_csv('China\China Alcohol Male.csv')
A_w=pd.read_csv('China\China Alcohol Fmale.csv')

NASH_m=np.array(NASH_m)
NASH_w=np.array(NASH_w)
C_m=np.array(C_m)
C_w=np.array(C_w)
B_m=np.array(B_m)
B_w=np.array(B_w)
Other_m=np.array(Other_m)
Other_w=np.array(Other_w)
A_m=np.array(A_m)
A_w=np.array(A_w)

man=np.array([list(A_m[:,12]),list(B_m[:,13]),list(C_m[:,13]),list(NASH_m[:,13]),list(A_m[:,13]),list(Other_m[:,13])]).T
woman=np.array([list(A_w[:,12]),list(B_w[:,13]),list(C_w[:,13]),list(NASH_w[:,13]),list(A_w[:,13]),list(Other_w[:,13])]).T

man_bl=np.zeros((30,6))
woman_bl=np.zeros((30,6))
for i in range(len(man_bl)):
    man_bl[i,0]=man[i,0]
    woman_bl[i,0]=woman[i,0]
    for j in range(5):
        man_bl[i,j+1]=man[i,j+1]/(sum(man[i,1:]))
        woman_bl[i,j+1]=woman[i,j+1]/(sum(woman[i,1:]))
fig = plt.figure(figsize=(60, 20))
ax = fig.subplots(1, 2)

m=man_bl
for i in range(2):
    ax[i].spines['bottom'].set_linewidth(1.5)
    ax[i].spines['left'].set_linewidth(1.5)
    ax[i].spines['right'].set_linewidth(1.5)
    ax[i].spines['top'].set_linewidth(1.5)
    ax[i].xaxis.set_tick_params(labelsize=11)
    ax[i].yaxis.set_tick_params(labelsize=11) 

ax[0].barh(man_bl[:,0],man_bl[:,1],height=0.97,color='#00B49E',label='hepatitis B')
for a,b in zip(man_bl[:,1],man_bl[:,0]):
    c=a*100
    ax[0].text(a-0.35,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[0].barh(man_bl[:,0],man_bl[:,2],left=man_bl[:,1],height=0.97,color='#7DB2C6',label='hepatitis C')
for a,b,d in zip(man_bl[:,2],man_bl[:,0],man_bl[:,1]):
    c=a*100
    ax[0].text(a+d-0.046,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[0].barh(man_bl[:,0],man_bl[:,3],left=man_bl[:,1]+man_bl[:,2],height=0.97,color='#855C91',label='NASH')
for a,b in zip(man_bl[:,3],man_bl[:,0]):
    c=a*100
    ax[0].text(0.86,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[0].barh(man_bl[:,0],man_bl[:,4],left=man_bl[:,1]+man_bl[:,2]+man_bl[:,3],height=0.97,color='#FFA81F',label='alcohol use')
for a,b in zip(man_bl[:,4],man_bl[:,0]):
    c=a*100
    ax[0].text(0.915,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[0].barh(man_bl[:,0],man_bl[:,5],left=man_bl[:,1]+man_bl[:,2]+man_bl[:,3]+man_bl[:,4],height=0.97,color='#FA3C3E',label='other causes')
for a,b in zip(man_bl[:,5],man_bl[:,0]):
    c=a*100
    ax[0].text(0.975,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
fig.legend(loc='upper center',ncol=5,fontsize=14)

ax[1].barh(woman_bl[:,0],woman_bl[:,1],height=0.97,color='#00B49E',label='hepatitis B')
for a,b in zip(woman_bl[:,1],woman_bl[:,0]):
    c=a*100
    ax[1].text(a-0.2,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[1].barh(woman_bl[:,0],woman_bl[:,2],left=woman_bl[:,1],height=0.97,color='#7DB2C6',label='hepatitis C')
for a,b in zip(woman_bl[:,2],woman_bl[:,0]):
    c=a*100
    ax[1].text(0.55,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[1].barh(woman_bl[:,0],woman_bl[:,3],left=woman_bl[:,1]+woman_bl[:,2],height=0.97,color='#855C91',label='NASH')
for a,b in zip(woman_bl[:,3],woman_bl[:,0]):
    c=a*100
    ax[1].text(0.73,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[1].barh(woman_bl[:,0],woman_bl[:,4],left=woman_bl[:,1]+woman_bl[:,2]+woman_bl[:,3],height=0.97,color='#FFA81F',label='alcohol use')
for a,b in zip(woman_bl[:,4],woman_bl[:,0]):
    c=a*100
    ax[1].text(0.8,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[1].barh(woman_bl[:,0],woman_bl[:,5],left=woman_bl[:,1]+woman_bl[:,2]+woman_bl[:,3]+woman_bl[:,4],height=0.97,color='#FA3C3E',label='other causes')
for a,b in zip(woman_bl[:,5],woman_bl[:,0]):
    c=a*100
    ax[1].text(0.95,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)

