
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd 
Cha=pd.read_excel('Predicted data.xlsx',0)
USA=pd.read_excel('Predicted data.xlsx',1)
Kro=pd.read_excel('Predicted data.xlsx',2)
Mon=pd.read_excel('Predicted data.xlsx',3)
USA=np.array(USA)
Cha=np.array(Cha)
Kro=np.array(Kro)
Mon=np.array(Mon)
IB_y=np.array([Cha[:,0],USA[:,0],Kro[:,0],Mon[:,0]]).T
IB_y=IB_y[:30,:]
IB_yc=np.array([Cha[:,1],USA[:,1],Kro[:,1],Mon[:,1]]).T

IM_y=np.array([Cha[:,4],USA[:,4],Kro[:,4],Mon[:,4]]).T
IM_y=IM_y[:30,:]
IM_yc=np.array([Cha[:,5],USA[:,5],Kro[:,5],Mon[:,5]]).T

IF_y=np.array([Cha[:,2],USA[:,2],Kro[:,2],Mon[:,2]]).T
IF_y=IF_y[:30,:]
IF_yc=np.array([Cha[:,3],USA[:,3],Kro[:,3],Mon[:,3]]).T

fig, ax = plt.subplots(1,3, figsize=(10, 15))
for i in range(3):
    ax[i].spines['bottom'].set_linewidth(1.5)
    ax[i].spines['left'].set_linewidth(1.5)
    ax[i].spines['right'].set_visible(False)
    ax[i].spines['top'].set_visible(False)
    ax[i].xaxis.set_tick_params(labelsize=11)
    ax[i].yaxis.set_tick_params(labelsize=11) 
ro_chaB_mean=pd.DataFrame(IB_yc[:,0]).rolling(window=5).mean()
ro_chaB_std=pd.DataFrame(IB_yc[:,0]).rolling(window=5).std()
ro_USAB_mean=pd.DataFrame(IB_yc[:,1]).rolling(window=5).mean()
ro_USAB_std=pd.DataFrame(IB_yc[:,1]).rolling(window=5).std()
ro_KroB_mean=pd.DataFrame(IB_yc[:,2]).rolling(window=5).mean()
ro_KroB_std=pd.DataFrame(IB_yc[:,2]).rolling(window=5).std()
ro_MonB_mean=pd.DataFrame(IB_yc[:,3]).rolling(window=5).mean()
ro_MonB_std=pd.DataFrame(IB_yc[:,3]).rolling(window=5).std()
chaB_u=ro_chaB_mean+(ro_chaB_std*1.96)
chaB_u=chaB_u[30:]
chaB_d=ro_chaB_mean-(ro_chaB_std*1.96)
chaB_d=chaB_d[30:]
USAB_u=ro_USAB_mean+(ro_USAB_std*1.96)
USAB_u=USAB_u[30:]
USAB_d=ro_USAB_mean-(ro_USAB_std*1.96)
USAB_d=USAB_d[30:]
KroB_u=ro_KroB_mean+(ro_KroB_std*1.96)
KroB_u=KroB_u[30:]
KroB_d=ro_KroB_mean-(ro_KroB_std*1.96)
KroB_d=KroB_d[30:]
MonB_u=ro_MonB_mean+(ro_MonB_std*1.96)
MonB_u=MonB_u[30:]
MonB_d=ro_MonB_mean-(ro_MonB_std*1.96)
MonB_d=MonB_d[30:]

ro_chaM_mean=pd.DataFrame(IM_yc[:,0]).rolling(window=5).mean()
ro_chaM_std=pd.DataFrame(IM_yc[:,0]).rolling(window=5).std()
ro_USAM_mean=pd.DataFrame(IM_yc[:,1]).rolling(window=5).mean()
ro_USAM_std=pd.DataFrame(IM_yc[:,1]).rolling(window=5).std()
ro_KroM_mean=pd.DataFrame(IM_yc[:,2]).rolling(window=5).mean()
ro_KroM_std=pd.DataFrame(IM_yc[:,2]).rolling(window=5).std()
ro_MonM_mean=pd.DataFrame(IM_yc[:,3]).rolling(window=5).mean()
ro_MonM_std=pd.DataFrame(IM_yc[:,3]).rolling(window=5).std()
chaM_u=ro_chaM_mean+(ro_chaM_std*1.96)
chaM_u=chaM_u[30:]
chaM_d=ro_chaM_mean-(ro_chaM_std*1.96)
chaM_d=chaM_d[30:]
USAM_u=ro_USAM_mean+(ro_USAM_std*1.96)
USAM_u=USAM_u[30:]
USAM_d=ro_USAM_mean-(ro_USAM_std*1.96)
USAM_d=USAM_d[30:]
KroM_u=ro_KroM_mean+(ro_KroM_std*1.96)
KroM_u=KroM_u[30:]
KroM_d=ro_KroM_mean-(ro_KroM_std*1.96)
KroM_d=KroM_d[30:]
MonM_u=ro_MonM_mean+(ro_MonM_std*1.96)
MonM_u=MonM_u[30:]
MonM_d=ro_MonM_mean-(ro_MonM_std*1.96)
MonM_d=MonM_d[30:]

ro_chaF_mean=pd.DataFrame(IF_yc[:,0]).rolling(window=5).mean()
ro_chaF_std=pd.DataFrame(IF_yc[:,0]).rolling(window=5).std()
ro_USAF_mean=pd.DataFrame(IF_yc[:,1]).rolling(window=5).mean()
ro_USAF_std=pd.DataFrame(IF_yc[:,1]).rolling(window=5).std()
ro_KroF_mean=pd.DataFrame(IF_yc[:,2]).rolling(window=5).mean()
ro_KroF_std=pd.DataFrame(IF_yc[:,2]).rolling(window=5).std()
ro_MonF_mean=pd.DataFrame(IF_yc[:,3]).rolling(window=5).mean()
ro_MonF_std=pd.DataFrame(IF_yc[:,3]).rolling(window=5).std()
chaF_u=ro_chaF_mean+(ro_chaF_std*1.96)
chaF_u=chaF_u[30:]
chaF_d=ro_chaF_mean-(ro_chaF_std*1.96)
chaF_d=chaF_d[30:]
USAF_u=ro_USAF_mean+(ro_USAF_std*1.96)
USAF_u=USAF_u[30:]
USAF_d=ro_USAF_mean-(ro_USAF_std*1.96)
USAF_d=USAF_d[30:]
KroF_u=ro_KroF_mean+(ro_KroF_std*1.96)
KroF_u=KroF_u[30:]
KroF_d=ro_KroF_mean-(ro_KroF_std*1.96)
KroF_d=KroF_d[30:]
MonF_u=ro_MonF_mean+(ro_MonF_std*1.96)
MonF_u=MonF_u[30:]
MonF_d=ro_MonF_mean-(ro_MonF_std*1.96)
MonF_d=MonF_d[30:]
data=pd.read_excel('confidence interval.xlsx')
ax[0].plot(range(1990,1990+len(IB_yc)),IB_yc[:,0],label='China predicted data')
ax[0].plot(range(1990,1990+len(IB_y)),IB_y[:,0],label='China raw data')
ax[0].fill_between(range(1990+len(IB_y),1990+len(IB_yc)),data['ChaB_u'],data['ChaB_d'],color='cornflowerblue',alpha=0.6)
ax[0].plot(range(1990,1990+len(IB_yc)),IB_yc[:,1],label='USA predicted data')
ax[0].plot(range(1990,1990+len(IB_y)),IB_y[:,1],label='USA raw data')

ax[0].fill_between(range(1990+len(IB_y),1990+len(IB_yc)),data['USAB_u'],data['USAB_d'],color='mediumspringgreen',alpha=0.6)
ax[0].plot(range(1990,1990+len(IB_yc)),IB_yc[:,2],label='Korea predicted data')
ax[0].plot(range(1990,1990+len(IB_y)),IB_y[:,2],label='Korea raw data')
ax[0].fill_between(range(1990+len(IB_y),1990+len(IB_yc)),data['KroB_u'],data['KroB_d'],color='mediumorchid',alpha=0.6)
fig.legend(fontsize=12,frameon=False,loc='upper center',ncol=3)

ax[1].plot(range(1990,1990+len(IM_yc)),IM_yc[:,0],label='China predicted data')
ax[1].plot(range(1990,1990+len(IM_y)),IM_y[:,0],label='China raw data')
ax[1].fill_between(range(1990+len(IM_y),1990+len(IM_yc)),data['ChaM_u'],data['ChaM_d'],color='cornflowerblue',alpha=0.6)
ax[1].plot(range(1990,1990+len(IM_yc)),IM_yc[:,1],label='USA predicted data')
ax[1].plot(range(1990,1990+len(IM_y)),IM_y[:,1],label='USA raw data')

ax[1].fill_between(range(1990+len(IM_y),1990+len(IM_yc)),data['USAM_u'],data['USAM_d'],color='mediumspringgreen',alpha=0.6)
ax[1].plot(range(1990,1990+len(IM_yc)),IM_yc[:,2],label='Korea predicted data')
ax[1].plot(range(1990,1990+len(IM_y)),IM_y[:,2],label='Korea raw data')
ax[1].fill_between(range(1990+len(IM_y),1990+len(IM_yc)),data['KroM_u'],data['KroM_d'],color='mediumorchid',alpha=0.6)



ax[2].plot(range(1990,1990+len(IF_yc)),IF_yc[:,0],label='China predicted data')
ax[2].plot(range(1990,1990+len(IF_y)),IF_y[:,0],label='China raw data')
ax[2].fill_between(range(1990+len(IF_y),1990+len(IF_yc)),data['ChaF_u'],data['ChaF_d'],color='cornflowerblue',alpha=0.6)
ax[2].plot(range(1990,1990+len(IF_yc)),IF_yc[:,1],label='USA predicted data')
ax[2].plot(range(1990,1990+len(IF_y)),IF_y[:,1],label='USA raw data')

ax[2].fill_between(range(1990+len(IF_y),1990+len(IF_yc)),data['USAF_u'],data['USAF_d'],color='mediumspringgreen',alpha=0.6)
ax[2].plot(range(1990,1990+len(IF_yc)),IF_yc[:,2],label='Korea predicted data')
ax[2].plot(range(1990,1990+len(IF_y)),IF_y[:,2],label='Korea raw data')
ax[2].fill_between(range(1990+len(IF_y),1990+len(IF_yc)),data['KroF_u'],data['KroF_d'],color='mediumorchid',alpha=0.6)


ax[0].text(-0.08, 1.02, chr(65), transform=ax[0].transAxes, fontsize=20)
ax[1].text(-0.08, 1.02, chr(66), transform=ax[1].transAxes, fontsize=20)
ax[2].text(-0.08, 1.02, chr(67), transform=ax[2].transAxes, fontsize=20)

fig, ax1 = plt.subplots(1,3, figsize=(10, 15))
for i in range(3):
    ax1[i].spines['bottom'].set_linewidth(1.5)
    ax1[i].spines['left'].set_linewidth(1.5)
    ax1[i].spines['right'].set_visible(False)
    ax1[i].spines['top'].set_visible(False)
    ax1[i].xaxis.set_tick_params(labelsize=11)
    ax1[i].yaxis.set_tick_params(labelsize=11) 
ax1[0].plot(range(1990,1990+len(IM_yc)),IB_yc[:,3],label='Mongolia predicted data')
ax1[0].plot(range(1990,1990+len(IM_y)),IB_y[:,3],label='Mongolia raw data')
ax1[0].fill_between(range(1990+len(IM_y),1990+len(IM_yc)),data['MonB_u'],data['MonB_d'],color='cornflowerblue',alpha=0.6)
fig.legend(fontsize=12,frameon=False,loc='upper center',ncol=2)
ax1[1].plot(range(1990,1990+len(IM_yc)),IM_yc[:,3],label='Mongolia predicted data')
ax1[1].plot(range(1990,1990+len(IM_y)),IM_y[:,3],label='Mongolia raw data')
ax1[1].fill_between(range(1990+len(IM_y),1990+len(IM_yc)),data['MonM_u'],data['MonM_d'],color='cornflowerblue',alpha=0.6)

ax1[2].plot(range(1990,1990+len(IM_yc)),IF_yc[:,3],label='Mongolia predicted data')
ax1[2].plot(range(1990,1990+len(IM_y)),IF_y[:,3],label='Mongolia raw data')
ax1[2].fill_between(range(1990+len(IM_y),1990+len(IM_yc)),data['MonF_u'],data['MonF_d'],color='cornflowerblue',alpha=0.6)

ax1[0].text(0.3, 1.02, chr(65), transform=ax[0].transAxes, fontsize=20)
ax1[1].text(1.4, 1.02, chr(66), transform=ax[1].transAxes, fontsize=20)
ax1[2].text(2.5, 1.02, chr(67), transform=ax[2].transAxes, fontsize=20)
