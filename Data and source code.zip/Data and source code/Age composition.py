
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
Inc=pd.read_excel("globalcan_I.xlsx")
Mort=pd.read_excel("globalcan_M.xlsx")
Inc=np.array(Inc)
Mort=np.array(Mort)
x_la=Inc[:,0]
fig, ax = plt.subplots(1, 2, figsize=(20, 20))
for i in range(2):
        ax[i].spines['bottom'].set_linewidth(1.5)
        ax[i].spines['left'].set_linewidth(1.5)
        ax[i].spines['right'].set_visible(False)
        ax[i].spines['top'].set_visible(False)
        ax[i].xaxis.set_tick_params(labelsize=11)
        ax[i].yaxis.set_tick_params(labelsize=11)
ax[0].set_ylabel("Incidence",fontsize=14)
ax[0].plot(x_la,Inc[:,3],linestyle='-',marker='^',markersize=8,label='USA')
ax[0].plot(x_la,Inc[:,4],linestyle='-',marker='d',markersize=8,label='Korea')
ax[0].plot(x_la,Inc[:,1],linestyle='-',marker='o',markersize=8,label='World')
ax[0].plot(x_la,Inc[:,2],linestyle='-',marker='*',markersize=8,label='China')
ax[0].legend(fontsize=9,frameon=False)

ax[1].set_ylabel("Mortality",fontsize=14)
ax[1].plot(x_la,Mort[:,3],linestyle='-',marker='^',markersize=8,label='USA')
ax[1].plot(x_la,Mort[:,4],linestyle='-',marker='d',markersize=8,label='Korea')
ax[1].plot(x_la,Mort[:,1],linestyle='-',marker='o',markersize=8,label='World')
ax[1].plot(x_la,Mort[:,2],linestyle='-',marker='*',markersize=8,label='China')


ax[1].legend(fontsize=9,frameon=False)

ax2 = fig.add_axes([0.2, 0.65, 0.21, 0.21])
ax2.plot(x_la, Inc[:,5], linestyle='-',marker='P',color='#844bb3',markersize=6,label='Mongolia')
ax2.set_ylabel('Incidence')
ax2.legend(fontsize=9,frameon=False)

ax3=fig.add_axes([0.63, 0.65, 0.21, 0.21])
ax3.plot(x_la,Mort[:,5],linestyle='-',marker='P',color='#844bb3',markersize=6,label='Mongolia')
ax3.set_ylabel('Mortality')
ax3.legend(fontsize=9,frameon=False)