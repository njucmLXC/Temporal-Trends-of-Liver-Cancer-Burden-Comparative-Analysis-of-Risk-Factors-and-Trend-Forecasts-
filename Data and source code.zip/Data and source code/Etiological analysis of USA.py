
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
NASH_m=pd.read_csv('USA\\USA NASH Male.csv')
NASH_w=pd.read_csv('USA\\USA NASH Fmale.csv')
C_m=pd.read_csv('USA\\USA Hepatitis C Male.csv')
C_w=pd.read_csv('USA\\USA Hepatitis C Fmale.csv')
B_m=pd.read_csv('USA\\USA Hepatitis B Male.csv')
B_w=pd.read_csv('USA\\USA Hepatitis B Fmale.csv')
Other_m=pd.read_csv('USA\\USA Other Male.csv')
Other_w=pd.read_csv('USA\\USA Other Fmale.csv')
A_m=pd.read_csv('USA\\USA Alcohol Male.csv')
A_w=pd.read_csv('USA\\USA Alcohol Fmale.csv')

NASH_m=np.array(NASH_m)
NASH_w=np.array(NASH_w)
C_m=np.array(C_m)
C_w=np.array(C_w)
B_m=np.array(B_m)
B_w=np.array(B_w)
Other_m=np.array(Other_m)
Other_w=np.array(Other_w)
A_m=np.array(A_m)
A_w=np.array(A_w)

man=np.array([list(A_m[:,12]),list(B_m[:,13]),list(C_m[:,13]),list(NASH_m[:,13]),list(A_m[:,13]),list(Other_m[:,13])]).T
woman=np.array([list(A_w[:,12]),list(B_w[:,13]),list(C_w[:,13]),list(NASH_w[:,13]),list(A_w[:,13]),list(Other_w[:,13])]).T

man_bl=np.zeros((30,6))
woman_bl=np.zeros((30,6))
for i in range(len(man_bl)):
    man_bl[i,0]=man[i,0]
    woman_bl[i,0]=woman[i,0]
    for j in range(5):
        man_bl[i,j+1]=man[i,j+1]/(sum(man[i,1:]))
        woman_bl[i,j+1]=woman[i,j+1]/(sum(woman[i,1:]))
fig = plt.figure(figsize=(60, 20))
ax = fig.subplots(1, 2)

m=man_bl
for i in range(2):
    ax[i].spines['bottom'].set_linewidth(1.5)
    ax[i].spines['left'].set_linewidth(1.5)
    ax[i].spines['right'].set_linewidth(1.5)
    ax[i].spines['top'].set_linewidth(1.5)
    ax[i].xaxis.set_tick_params(labelsize=11)
    ax[i].yaxis.set_tick_params(labelsize=11) 

ax[0].barh(man_bl[:,0],man_bl[:,1],height=0.97,color='#00B49E',label='hepatitis B')
for a,b in zip(man_bl[:,1],man_bl[:,0]):
    c=a*100
    ax[0].text(a-0.08,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[0].barh(man_bl[:,0],man_bl[:,2],left=man_bl[:,1],height=0.97,color='#7DB2C6',label='hepatitis C')
for a,b in zip(man_bl[:,2],man_bl[:,0]):
    c=a*100
    ax[0].text(a+0.02,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[0].barh(man_bl[:,0],man_bl[:,3],left=man_bl[:,1]+man_bl[:,2],height=0.97,color='#855C91',label='NASH')
b=man_bl[:,0]
for a,b in zip(man_bl[:,3],man_bl[:,0]):
        c=a*100
        if abs(a-0.0753826)<0.00001:
            ax[0].text(a+0.52,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0684361)<0.0001:
            ax[0].text(a+0.44,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.073544)<0.0001:
            ax[0].text(a+0.44,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0772396)<0.0000001:
            ax[0].text(a+0.44,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0805975)<0.0001:
            ax[0].text(a+0.44,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0643114)<0.0001:
            ax[0].text(a+0.45,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0645935)<0.00001:
            ax[0].text(a+0.33,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0731627)<0.00001:
            ax[0].text(a+0.43,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0704544)<0.00001:
            ax[0].text(a+0.37,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0771689)<0.00001:
            ax[0].text(a+0.41,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0699581)<0.00001:
            ax[0].text(a+0.45,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0604321)<0.00001:
            ax[0].text(a+0.43,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0634204)<0.00001:
             ax[0].text(a+0.46,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
        elif abs(a-0.0773745)<0.00001:
             ax[0].text(a+0.44,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7) 
        elif abs(a-0.0829933)<0.00001:
             ax[0].text(a+0.4,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7) 
        else:
            ax[0].text(a+0.42,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[0].barh(man_bl[:,0],man_bl[:,4],left=man_bl[:,1]+man_bl[:,2]+man_bl[:,3],height=0.97,color='#FFA81F',label='alcohol use')
for a,b in zip(man_bl[:,4],man_bl[:,0]):
    c=a*100
    if abs(a-0.464557)<0.00001:
        ax[0].text(a+0.2,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
    elif abs(a-0.27791)<0.000001:
        ax[0].text(a+0.5,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
    else:
        ax[0].text(a+0.35,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[0].barh(man_bl[:,0],man_bl[:,5],left=man_bl[:,1]+man_bl[:,2]+man_bl[:,3]+man_bl[:,4],height=0.97,color='#FA3C3E',label='other causes')
for a,b in zip(man_bl[:,5],man_bl[:,0]):
    c=a*100
    ax[0].text(0.97,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
fig.legend(loc='upper center',ncol=5,fontsize=14)

ax[1].barh(woman_bl[:,0],woman_bl[:,1],height=0.97,color='#00B49E',label='hepatitis B')
for a,b in zip(woman_bl[:,1],woman_bl[:,0]):
    c=a*100
    ax[1].text(a-0.06,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[1].barh(woman_bl[:,0],woman_bl[:,2],left=woman_bl[:,1],height=0.97,color='#7DB2C6',label='hepatitis C')
for a,b in zip(woman_bl[:,2],woman_bl[:,0]):
    c=a*100
    ax[1].text(0.35,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[1].barh(woman_bl[:,0],woman_bl[:,3],left=woman_bl[:,1]+woman_bl[:,2],height=0.97,color='#855C91',label='NASH')
for a,b in zip(woman_bl[:,3],woman_bl[:,0]):
    c=a*100
    if abs(a-0.0950855)<0.000001:
        ax[1].text(a+0.57,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
    elif abs(a-0.0986882)<0.000001:
        ax[1].text(a+0.54,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
    elif abs(a-0.163218)<0.0001:
        ax[1].text(a+0.43,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
    elif abs(a-0.110486)<0.0001:
        ax[1].text(a+0.57,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7) 
    elif abs(a-0.150157)<0.0001:
        ax[1].text(a+0.5,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7) 
    elif abs(a-0.0957712)<0.0001:
        ax[1].text(a+0.55,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)    
    else:
        ax[1].text(a+0.52,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[1].barh(woman_bl[:,0],woman_bl[:,4],left=woman_bl[:,1]+woman_bl[:,2]+woman_bl[:,3],height=0.97,color='#FFA81F',label='alcohol use')
for a,b in zip(woman_bl[:,4],woman_bl[:,0]):
    c=a*100
    ax[1].text(0.768,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)
ax[1].barh(woman_bl[:,0],woman_bl[:,5],left=woman_bl[:,1]+woman_bl[:,2]+woman_bl[:,3]+woman_bl[:,4],height=0.97,color='#FA3C3E',label='other causes')
for a,b in zip(woman_bl[:,5],woman_bl[:,0]):
    c=a*100
    ax[1].text(0.94,b-0.2,'%.2f'%c+'%',ha='center',fontsize=7)


