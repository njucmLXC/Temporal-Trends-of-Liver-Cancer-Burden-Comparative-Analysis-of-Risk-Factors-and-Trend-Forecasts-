

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
Mon_D_B=pd.read_excel("Time series diagram dataset\Mongolia_D_B.xlsx")
Cha_D_B=pd.read_excel("Time series diagram dataset\China_D_B.xlsx")
USA_D_B=pd.read_excel("Time series diagram dataset\\USA_D_B.xlsx")
Kor_D_B=pd.read_excel("Time series diagram dataset\Korea_D_B.xlsx")
Mon_D_M=pd.read_excel("Time series diagram dataset\Mongolia_D_M.xlsx")
Cha_D_M=pd.read_excel("Time series diagram dataset\China_D_M.xlsx")
USA_D_M=pd.read_excel("Time series diagram dataset\\USA_D_M.xlsx")
Kor_D_M=pd.read_excel("Time series diagram dataset\Korea_D_M.xlsx")
Mon_D_F=pd.read_excel("Time series diagram dataset\Mongolia_D_F.xlsx")
Cha_D_F=pd.read_excel("Time series diagram dataset\China_D_F.xlsx")
USA_D_F=pd.read_excel("Time series diagram dataset\\USA_D_F.xlsx")
Kor_D_F=pd.read_excel("Time series diagram dataset\Korea_D_F.xlsx")
Mon_I_B=pd.read_excel("Time series diagram dataset\Mongolia_I_B.xlsx")
Cha_I_B=pd.read_excel("Time series diagram dataset\China_I_B.xlsx")
USA_I_B=pd.read_excel("Time series diagram dataset\\USA_I_B.xlsx")
Kor_I_B=pd.read_excel("Time series diagram dataset\Korea_I_B.xlsx")
Mon_I_M=pd.read_excel("Time series diagram dataset\Mongolia_I_M.xlsx")
Cha_I_M=pd.read_excel("Time series diagram dataset\China_I_M.xlsx")
USA_I_M=pd.read_excel("Time series diagram dataset\\USA_I_M.xlsx")
Kor_I_M=pd.read_excel("Time series diagram dataset\Korea_I_M.xlsx")
Mon_I_F=pd.read_excel("Time series diagram dataset\Mongolia_I_F.xlsx")
Cha_I_F=pd.read_excel("Time series diagram dataset\China_I_F.xlsx")
USA_I_F=pd.read_excel("Time series diagram dataset\\USA_I_F.xlsx")
Kor_I_F=pd.read_excel("Time series diagram dataset\Korea_I_F.xlsx")
Mon_A_B=pd.read_excel("Time series diagram dataset\Mongolia_A_B.xlsx")
Cha_A_B=pd.read_excel("Time series diagram dataset\China_A_B.xlsx")
USA_A_B=pd.read_excel("Time series diagram dataset\\USA_A_B.xlsx")
Kor_A_B=pd.read_excel("Time series diagram dataset\Korea_A_B.xlsx")
Mon_A_M=pd.read_excel("Time series diagram dataset\Mongolia_A_M.xlsx")
Cha_A_M=pd.read_excel("Time series diagram dataset\China_A_M.xlsx")
USA_A_M=pd.read_excel("Time series diagram dataset\\USA_A_M.xlsx")
Kor_A_M=pd.read_excel("Time series diagram dataset\Korea_A_M.xlsx")
Mon_A_F=pd.read_excel("Time series diagram dataset\Mongolia_A_F.xlsx")
Cha_A_F=pd.read_excel("Time series diagram dataset\China_A_F.xlsx")
USA_A_F=pd.read_excel("Time series diagram dataset\\USA_A_F.xlsx")
Kor_A_F=pd.read_excel("Time series diagram dataset\Korea_A_F.xlsx")
Mon_D_B=np.array(Mon_D_B)
Cha_D_B=np.array(Cha_D_B)
USA_D_B=np.array(USA_D_B)
Kor_D_B=np.array(Kor_D_B)
Mon_D_M=np.array(Mon_D_M)
Cha_D_M=np.array(Cha_D_M)
USA_D_M=np.array(USA_D_M)
Kor_D_M=np.array(Kor_D_M)
Mon_D_F=np.array(Mon_D_F)
Cha_D_F=np.array(Cha_D_F)
USA_D_F=np.array(USA_D_F)
Kor_D_F=np.array(Kor_D_F)
Mon_I_B=np.array(Mon_I_B)
Cha_I_B=np.array(Cha_I_B)
USA_I_B=np.array(USA_I_B)
Kor_I_B=np.array(Kor_I_B)
Mon_I_M=np.array(Mon_I_M)
Cha_I_M=np.array(Cha_I_M)
USA_I_M=np.array(USA_I_M)
Kor_I_M=np.array(Kor_I_M)
Mon_I_F=np.array(Mon_I_F)
Cha_I_F=np.array(Cha_I_F)
USA_I_F=np.array(USA_I_F)
Kor_I_F=np.array(Kor_I_F)
Mon_A_B=np.array(Mon_A_B)
Cha_A_B=np.array(Cha_A_B)
USA_A_B=np.array(USA_A_B)
Kor_A_B=np.array(Kor_A_B)
Mon_A_M=np.array(Mon_A_M)
Cha_A_M=np.array(Cha_A_M)
USA_A_M=np.array(USA_A_M)
Kor_A_M=np.array(Kor_A_M)
Mon_A_F=np.array(Mon_A_F)
Cha_A_F=np.array(Cha_A_F)
USA_A_F=np.array(USA_A_F)
Kor_A_F=np.array(Kor_A_F)
Mon_D_B_year=list(Mon_D_B[:,12])
MonDB=Mon_D_B[:,13]
Cha_D_B_year=list(Cha_D_B[:,12])
ChaDB=Cha_D_B[:,13]
USA_D_B_year=list(USA_D_B[:,12])
USADB=USA_D_B[:,13]
Kor_D_B_year=list(Kor_D_B[:,12])
KorDB=Kor_D_B[:,13]
Mon_D_M_year=list(Mon_D_M[:,12])
MonDM=Mon_D_M[:,13]
Cha_D_M_year=list(Cha_D_M[:,12])
ChaDM=Cha_D_M[:,13]
USA_D_M_year=list(USA_D_M[:,12])
USADM=USA_D_M[:,13]
Kor_D_M_year=list(Kor_D_M[:,12])
KorDM=Kor_D_M[:,13]
Mon_D_F_year=list(Mon_D_F[:,12])
MonDF=Mon_D_F[:,13]
Cha_D_F_year=list(Cha_D_F[:,12])
ChaDF=Cha_D_F[:,13]
USA_D_F_year=list(USA_D_F[:,12])
USADF=USA_D_F[:,13]
Kor_D_F_year=list(Kor_D_F[:,12])
KorDF=Kor_D_F[:,13]
Mon_I_B_year=list(Mon_I_B[:,12])
MonIB=Mon_I_B[:,13]
Cha_I_B_year=list(Cha_I_B[:,12])
ChaIB=Cha_I_B[:,13]
USA_I_B_year=list(USA_I_B[:,12])
USAIB=USA_I_B[:,13]
Kor_I_B_year=list(Kor_I_B[:,12])
KorIB=Kor_I_B[:,13]
Mon_I_M_year=list(Mon_I_M[:,12])
MonIM=Mon_I_M[:,13]
Cha_I_M_year=list(Cha_I_M[:,12])
ChaIM=Cha_I_M[:,13]
USA_I_M_year=list(USA_I_M[:,12])
USAIM=USA_I_M[:,13]
Kor_I_M_year=list(Kor_I_M[:,12])
KorIM=Kor_I_M[:,13]
Mon_I_F_year=list(Mon_I_F[:,12])
MonIF=Mon_I_F[:,13]
Cha_I_F_year=list(Cha_I_F[:,12])
ChaIF=Cha_I_F[:,13]
USA_I_F_year=list(USA_I_F[:,12])
USAIF=USA_I_F[:,13]
Kor_I_F_year=list(Kor_I_F[:,12])
KorIF=Kor_I_F[:,13]
Mon_A_B_year=list(Mon_A_B[:,12])
MonAB=Mon_A_B[:,13]
Cha_A_B_year=list(Cha_A_B[:,12])
ChaAB=Cha_A_B[:,13]
USA_A_B_year=list(USA_A_B[:,12])
USAAB=USA_A_B[:,13]
Kor_A_B_year=list(Kor_A_B[:,12])
KorAB=Kor_A_B[:,13]
Mon_A_M_year=list(Mon_A_M[:,12])
MonAM=Mon_A_M[:,13]
Cha_A_M_year=list(Cha_A_M[:,12])
ChaAM=Cha_A_M[:,13]
USA_A_M_year=list(USA_A_M[:,12])
USAAM=USA_A_M[:,13]
Kor_A_M_year=list(Kor_A_M[:,12])
KorAM=Kor_A_M[:,13]
Mon_A_F_year=list(Mon_A_F[:,12])
MonAF=Mon_A_F[:,13]
Cha_A_F_year=list(Cha_A_F[:,12])
ChaAF=Cha_A_F[:,13]
USA_A_F_year=list(USA_A_F[:,12])
USAAF=USA_A_F[:,13]
Kor_A_F_year=list(Kor_A_F[:,12])
KorAF=Kor_A_F[:,13]
fig, ax = plt.subplots(3, 3, figsize=(10, 10))
for i in range(3):
    for j in range(3):
        ax[i, j].spines['bottom'].set_linewidth(1.5)
        ax[i, j].spines['left'].set_linewidth(1.5)
        ax[i,j].spines['right'].set_visible(False)
        ax[i,j].spines['top'].set_visible(False)
        ax[i,j].xaxis.set_tick_params(labelsize=11)
        ax[i,j].yaxis.set_tick_params(labelsize=11) 
ax[0,0].set_ylabel("ASIR")
ax[0,0].plot(Mon_I_B_year,MonIB,linestyle='-',marker='o',markersize=5,label='Mogolia')
ax[0,0].plot(Cha_I_B_year,ChaIB,linestyle='-',marker='*',markersize=5,label='China')
ax[0,0].plot(USA_I_B_year,USAIB,linestyle='-',marker='^',markersize=5,label='USA')
ax[0,0].plot(Kor_I_B_year,KorIB,linestyle='-',marker='d',markersize=5,label='Korea') 
ax[0,0].legend(fontsize=9,frameon=False)
ax[0,1].plot(Mon_I_M_year,MonIM,linestyle='-',marker='o',markersize=5,label='Mogolia')
ax[0,1].plot(Cha_I_M_year,ChaIM,linestyle='-',marker='*',markersize=5,label='China')
ax[0,1].plot(USA_I_M_year,USAIM,linestyle='-',marker='^',markersize=5,label='USA')
ax[0,1].plot(Kor_I_M_year,KorIM,linestyle='-',marker='d',markersize=5,label='Korea')
ax[0,2].plot(Mon_I_F_year,MonIF,linestyle='-',marker='o',markersize=5,label='Mogolia')
ax[0,2].plot(Cha_I_F_year,ChaIF,linestyle='-',marker='*',markersize=5,label='China')
ax[0,2].plot(USA_I_F_year,USAIF,linestyle='-',marker='^',markersize=5,label='USA')
ax[0,2].plot(Kor_I_F_year,KorIF,linestyle='-',marker='d',markersize=5,label='Korea')
ax[1,0].set_ylabel("ASMR")
ax[1,0].plot(Mon_D_B_year,MonDB,linestyle='-',marker='o',markersize=5,label='Mogolia')
ax[1,0].plot(Cha_D_B_year,ChaDB,linestyle='-',marker='*',markersize=5,label='China')
ax[1,0].plot(USA_D_B_year,USADB,linestyle='-',marker='^',markersize=5,label='USA')
ax[1,0].plot(Kor_D_B_year,KorDB,linestyle='-',marker='d',markersize=5,label='Korea') 

ax[1,1].plot(Mon_D_M_year,MonDM,linestyle='-',marker='o',markersize=5,label='Mogolia')
ax[1,1].plot(Cha_D_M_year,ChaDM,linestyle='-',marker='*',markersize=5,label='China')
ax[1,1].plot(USA_D_M_year,USADM,linestyle='-',marker='^',markersize=5,label='USA')
ax[1,1].plot(Kor_D_M_year,KorDM,linestyle='-',marker='d',markersize=5,label='Korea')
ax[1,2].plot(Mon_D_F_year,MonDF,linestyle='-',marker='o',markersize=5,label='Mogolia')
ax[1,2].plot(Cha_D_F_year,ChaDF,linestyle='-',marker='*',markersize=5,label='China')
ax[1,2].plot(USA_D_F_year,USADF,linestyle='-',marker='^',markersize=5,label='USA')
ax[1,2].plot(Kor_D_F_year,KorDF,linestyle='-',marker='d',markersize=5,label='Korea')
ax[2,0].set_ylabel("ASDR")
ax[2,0].plot(Mon_A_B_year,MonAB,linestyle='-',marker='o',markersize=5,label='Mogolia')
ax[2,0].plot(Cha_A_B_year,ChaAB,linestyle='-',marker='*',markersize=5,label='China')
ax[2,0].plot(USA_A_B_year,USAAB,linestyle='-',marker='^',markersize=5,label='USA')
ax[2,0].plot(Kor_A_B_year,KorAB,linestyle='-',marker='d',markersize=5,label='Korea') 

ax[2,1].plot(Mon_A_M_year,MonAM,linestyle='-',marker='o',markersize=5,label='Mogolia')
ax[2,1].plot(Cha_A_M_year,ChaAM,linestyle='-',marker='*',markersize=5,label='China')
ax[2,1].plot(USA_A_M_year,USAAM,linestyle='-',marker='^',markersize=5,label='USA')
ax[2,1].plot(Kor_A_M_year,KorAM,linestyle='-',marker='d',markersize=5,label='Korea')
ax[2,2].plot(Mon_A_F_year,MonAF,linestyle='-',marker='o',markersize=5,label='Mogolia')
ax[2,2].plot(Cha_A_F_year,ChaAF,linestyle='-',marker='*',markersize=5,label='China')
ax[2,2].plot(USA_A_F_year,USAAF,linestyle='-',marker='^',markersize=5,label='USA')
ax[2,2].plot(Kor_A_F_year,KorAF,linestyle='-',marker='d',markersize=5,label='Korea')
for i in range(3):  
    ax[i,0].text(-0.08, 1.02, chr(i+65), transform=ax[i,0].transAxes,fontsize=20)
