
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

SH=pd.read_excel('CI5.xlsx',0)
WH=pd.read_excel('CI5.xlsx',1)
JS=pd.read_excel('CI5.xlsx',2)
LSJ=pd.read_excel('CI5.xlsx',3)
UT=pd.read_excel('CI5.xlsx',4)
MXG=pd.read_excel('CI5.xlsx',5)
SE=pd.read_excel('CI5.xlsx',6)
FS=pd.read_excel('CI5.xlsx',7)
JZ=pd.read_excel('CI5.xlsx',8)


SH=np.array(SH)
WH=np.array(WH)
JS=np.array(JS)
LSJ=np.array(LSJ)
UT=np.array(UT)
MXG=np.array(MXG)
SE=np.array(SE)
FS=np.array(FS)
JZ=np.array(JZ)
df = pd.DataFrame(SH[:,1:],
                 index=SH[:,0],
                 columns=pd.Index(['Cruderate_male','Cruderate_female','ASR(W)_male','ASR(W)_female']))
df1 = pd.DataFrame(WH[:,1:],
                 index=WH[:,0],
                 columns=pd.Index(['Cruderate_male','Cruderate_female','ASR(W)_male','ASR(W)_female']))
df2 = pd.DataFrame(JS[:,1:],
                 index=JS[:,0],
                 columns=pd.Index(['Cruderate_male','Cruderate_female','ASR(W)_male','ASR(W)_female']))
df3 = pd.DataFrame(LSJ[:,1:],
                 index=LSJ[:,0],
                 columns=pd.Index(['Cruderate_male','Cruderate_female','ASR(W)_male','ASR(W)_female']))
df4 = pd.DataFrame(UT[:,1:],
                 index=UT[:,0],
                 columns=pd.Index(['Cruderate_male','Cruderate_female','ASR(W)_male','ASR(W)_female']))
df5 = pd.DataFrame(MXG[:,1:],
                 index=MXG[:,0],
                 columns=pd.Index(['Cruderate_male','Cruderate_female','ASR(W)_male','ASR(W)_female']))
df6 = pd.DataFrame(SE[:,1:],
                 index=SE[:,0],
                 columns=pd.Index(['Cruderate_male','Cruderate_female','ASR(W)_male','ASR(W)_female']))
df7 = pd.DataFrame(FS[:,1:],
                 index=FS[:,0],
                 columns=pd.Index(['Cruderate_male','Cruderate_female','ASR(W)_male','ASR(W)_female']))
df8 = pd.DataFrame(JZ[:,1:],
                 index=JZ[:,0],
                 columns=pd.Index(['Cruderate_male','Cruderate_female','ASR(W)_male','ASR(W)_female']))
fig=plt.figure(figsize=(30, 30))
axes = fig.subplots(3, 3)
for i in range(3):
    for j in range(3):
        axes[i,j].spines['bottom'].set_linewidth(1.5)
        axes[i,j].spines['left'].set_linewidth(1.5)
        axes[i,j].spines['right'].set_visible(False)
        axes[i,j].spines['top'].set_visible(False)
df.plot.bar(ax=axes[0,0],alpha=0.7,rot=0,legend=False,width=0.6)
fig.legend(loc='upper center', ncol=4,fontsize=14)
df1.plot.bar(ax=axes[0,1],alpha=0.7,rot=0,legend=False,width=0.6)
df2.plot.bar(ax=axes[0,2],alpha=0.7,rot=0,legend=False,width=0.6)
df3.plot.bar(ax=axes[1,0],alpha=0.7,rot=0,legend=False,width=0.6)
df4.plot.bar(ax=axes[1,1],alpha=0.7,rot=0,legend=False,width=0.6)
df5.plot.bar(ax=axes[1,2],alpha=0.7,rot=0,legend=False,width=0.6)
df6.plot.bar(ax=axes[2,0],alpha=0.7,rot=0,legend=False,width=0.6)
df7.plot.bar(ax=axes[2,1],alpha=0.7,rot=0,legend=False,width=0.6)
df8.plot.bar(ax=axes[2,2],alpha=0.7,rot=0,legend=False,width=0.6)
for i in range(3):  
    axes[i,0].text(-0.1, 1.02, chr(i+65), transform=axes[i,0].transAxes,fontsize=20)
plt.show()
plt.savefig('CI5City Comparison.tif',dpi=300)